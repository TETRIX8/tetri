TOKEN = '6824448730:AAE2CpRxyO8KCS7HlIIrIRmUgR9pD60-AbQ'
admins = 1404494933
chat = -1001965151482

# Наш telegram форум https://na-sha.ru/
